#include <stdio.h>// Standard input and output header file
#include <conio.h>// Console Input/Output functions
#include <string.h>// String functions
#include<windows.h>//contains declarations for all of the functions in the Windows API//
#define CANDIDATE_COUNT 8 // constant defined
#define FEEDBACK_LENGTH 100
// Structure to represent a Candidate
struct Candidate {
    char name[50]; // member of structure
    int votesCount;
};

// Structure to store Feedback
struct Feedback {
    char feedback[FEEDBACK_LENGTH]; // character array feedback
};

// Function to cast a vote for a candidate
void castVote(struct Candidate *candidates) {//pointer to an array of struct Candidate as an argument
    int choice;
    printf("\n\n ### CANDIDATES WHO TOOK PART IN THIS ELECTION ###\n\n");
    for (int i = 0; i < CANDIDATE_COUNT; i++) {
        printf("%d.%s\n", i + 1, candidates[i].name);
    }
    printf("%d.%s\n", CANDIDATE_COUNT + 1, "None of These");
    printf("\n\n Input your choice (1 - %d): ", CANDIDATE_COUNT + 1);
    scanf("%d", &choice);
    if (choice >= 1 && choice <= CANDIDATE_COUNT) {
        candidates[choice - 1].votesCount++;//user's vote choice is 1-based (1 to CANDIDATE_COUNT)
        printf("\nYOUR VOTE HAS BEEN CASTED...!!");
    } else if (choice == CANDIDATE_COUNT + 1) {
        printf("\nSpoiled Votes Counted!");
    } else {
        printf("\nError: Wrong Choice! Please retry.");
    }

    Sleep(1000);
    system("cls");
}

// Function to display voting statistics
void votesCount(struct Candidate *candidates) {
    printf("\n\n HERE IS THE VOTING STATISTICS\n");

    for (int i = 0; i < CANDIDATE_COUNT; i++) {
        printf("\n %s - %d", candidates[i].name, candidates[i].votesCount);
    }

    getchar(); // Clear the newline character from previous input
}

// Function to find the leading candidate
void getLeadingCandidate(struct Candidate *candidates) {
    int leadingIndex = 0;

    for (int i = 1; i < CANDIDATE_COUNT; i++) {
        if (candidates[i].votesCount > candidates[leadingIndex].votesCount) {
            leadingIndex = i;
        }
    }

    printf("\n\n #### Leading Candidate Till Now is ####\n\n");
    printf("[%s]", candidates[leadingIndex].name);
}

// Function to collect exit poll feedback
void collectExitPollFeedback(struct Feedback *exitPollFeedback) {
    printf("\nEnter your feedback for the voting system: ");
    getchar(); // Clear the newline character from previous input
    fgets(exitPollFeedback->feedback, sizeof(exitPollFeedback->feedback), stdin);
    printf("\nThank you for providing your feedback!\n");
}
// Function to display the main menu and handle user choices
void display() {
    int choice;
    Candidate candidates[CANDIDATE_COUNT] = {
        {"Imran Khan PTI", 0},
        {"Nawaz Shareef PMLN", 0},
        {"Asif ali zardari PPP", 0},
        {"Molana Fazl-ur-Rehman JUI", 0},
        {"Siraj-ul-Haq JI", 0},
        {"Muslim League Q", 0},
        {"Mustafa Kamal PSZP", 0},
        {"Sheikh Rasheed ALP", 0}
    };

    Feedback exitPollFeedback;
    system("Color 70");
    printf("\n\n ......... Welcome to Election/Voting System.........");
    Sleep(1000);

    do {
        printf("\n\n 1. Cast the Vote\n");
        Sleep(1000);
        printf("\n 2. Find Vote Count\n");
        Sleep(1000);
        printf("\n 3. Find leading Candidate\n");
        Sleep(1000);
        printf("\n 4. Provide Feedback\n");
        Sleep(1000);
        printf("\n 0. Program Details\n");
        printf("\n\n Please enter your choice: ");
        Sleep(1000);
        scanf("%d", &choice);
        system("cls");

        switch (choice) {
            case 1:
                castVote(candidates);
                break;
            case 2:
                votesCount(candidates);
                break;
            case 3:
                getLeadingCandidate(candidates);
                break;
            case 4:
                printf("\n\n ### EXIT POLLS ###\n");
                printf("\nPlease provide feedback on the voting system.\n");
                collectExitPollFeedback(&exitPollFeedback);
                break;
            default:
                printf("\n THANK YOU FOR VOTING HERE...!\n");
                Sleep(3000);
                printf("\n\n..MADE BY..\n");
                Sleep(2000);
                printf("Ghani Abdul Rehman Khan");
                Sleep(3000);
                printf("\n\n\"SE 2nd C\"");
                Sleep(4000);
                printf("\n\n TEACHER \"FATIMA HAMEED\"\n\n");
                Sleep(2000);
        }

        getchar(); // Clear the newline character from previous input

        char repeatChoice;
        printf("\n\nDo you want to go back to the main menu? (y/n): ");
        scanf(" %c", &repeatChoice);
        if (repeatChoice == 'n' || repeatChoice == 'N') {
            break;
        }
    } while (1);
}

int main() {
    system("Color 0A"); // Set the console background and text color
    printf("\n\n\t\t===============================");
    printf("\n\t\t|  WELCOME TO ELECTION/VOTING |");
    printf("\n\t\t|          SYSTEM             |");
    printf("\n\t\t===============================");
    Sleep(3000);
    printf("\n\n\t  ~~~ THIS PANEL IS PASSWORD PROTECTED ~~~");
    Sleep(3000);

    char pass[10], password[10] = "comsats";
    int c = 0;

    printf("\n\n\t\tKindly Enter the password to login: ");
    int i = 0;
    char ch;

    while (1) {
        ch = getch();

        if (ch == 13) // The code checks if the character read is the Enter key
		// (ASCII value 13). If the Enter key is pressed, the loop is exited using break, 
		//and the password input process is completed.
            break;
        else if (ch == 8) // If the character read is the Backspace key 
		//(ASCII value 8), the code enters this block.
        {
            if (i > 0) {
                i--;
                printf("\b \b"); // Move cursor back, print space, move cursor back again
            }
        } else {
            pass[i] = ch;
            i++;
            printf("*");
        }
    }

    pass[i] = '\0'; // Null-terminate the password string
    printf("\n\n\tSystem Is Checking Your Password...");
    Sleep(2000);

    if (strcmp(pass, password) == 0) {// strcmp function is used to compare the string arguments 
    // it compares strings lexicographically which means it compares both the strings character by character.
    // It starts comparing the very first character of strings until the characters of both strings
    // are equal or NULL character is found.//
        printf("\n\n\tPASSWORD MATCHED!");
        printf("\n\n\tLOADING");
        Sleep(3000);

        for (c = 0; c <= 9; c++) { // Loop used for printing dots in front of LOADING.
            printf(".");
            Sleep(1000);
        }

        system("cls");
        display();
    } else {
        printf("\n\tSORRY...");
        Sleep(3000);
        printf("\n\n\tYou entered the wrong password....\n\n");
        Sleep(3000);
        printf("\n\tTaking you back to the PASSWORD PANEL...");
        Sleep(3000);
        system("cls");
        main();
    }

    return 0;
}
/*
0 = Black      		 8 = Gray
    1 = Blue        9 = Light Blue
    2 = Green       A = Light Green
    3 = Aqua        B = Light Aqua
    4 = Red         C = Light Red
    5 = Purple      D = Light Purple
    6 = Yellow      E = Light Yellow
    7 = White       F = Bright White
    */

